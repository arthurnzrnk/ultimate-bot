"""Strategy package for the Ultimate Bot.

The strategies module contains individual trading strategy classes and a
router to select between them at runtime. To add a new strategy, create a
subclass of ``Strategy`` in a new file and update the ``StrategyRouter``
accordingly.
"""

from .base import Strategy  # noqa: F401
from .level_king_regime import LevelKingRegime  # noqa: F401
from .trend_follow import TrendFollow  # noqa: F401
from .router import StrategyRouter  # noqa: F401

__all__ = [
    "Strategy",
    "LevelKingRegime",
    "TrendFollow",
    "StrategyRouter",
]